import * as Schema from "effect/Schema";
import type { Probability } from "../domain/contracts.ts";

/**
 * The evaluation model deliberately uses opaque identities.  A name or a version
 * is useful for a report, but neither is enough to prove that the evaluated input
 * was unchanged.  Every content-bearing entity therefore carries a SHA-256 digest.
 */

const Identifier = Schema.NonEmptyString;
const NonNegativeInteger = Schema.Int.check(Schema.isGreaterThanOrEqualTo(0));
const PositiveInteger = Schema.Int.check(Schema.isGreaterThanOrEqualTo(1));
const NonNegativeFinite = Schema.Finite.check(Schema.isGreaterThanOrEqualTo(0));
const HexDigest = Schema.String.pipe(
  Schema.check(Schema.isPattern(/^[0-9a-f]{64}$/i)),
  Schema.brand("EvaluationDigest"),
);

export const EvaluationDigest = HexDigest;
export type EvaluationDigest = typeof EvaluationDigest.Type;

export const EvaluationId = Identifier.pipe(Schema.brand("EvaluationId"));
export type EvaluationId = typeof EvaluationId.Type;

export const FixtureId = Identifier.pipe(Schema.brand("EvaluationFixtureId"));
export type FixtureId = typeof FixtureId.Type;

export const RulePackId = Identifier.pipe(Schema.brand("EvaluationRulePackId"));
export type RulePackId = typeof RulePackId.Type;

export const LocalRuleId = Identifier.pipe(Schema.brand("EvaluationLocalRuleId"));
export type LocalRuleId = typeof LocalRuleId.Type;

export const QualifiedRuleId = Identifier.pipe(
  Schema.brand("EvaluationQualifiedRuleId"),
);
export type QualifiedRuleId = typeof QualifiedRuleId.Type;

export const ConfigurationCaseId = Identifier.pipe(
  Schema.brand("EvaluationConfigurationCaseId"),
);
export type ConfigurationCaseId = typeof ConfigurationCaseId.Type;

export const ScenarioId = Identifier.pipe(Schema.brand("EvaluationScenarioId"));
export type ScenarioId = typeof ScenarioId.Type;

export const ObservationId = Identifier.pipe(
  Schema.brand("EvaluationObservationId"),
);
export type ObservationId = typeof ObservationId.Type;

export const ComparisonId = Identifier.pipe(
  Schema.brand("EvaluationComparisonId"),
);
export type ComparisonId = typeof ComparisonId.Type;

export const RunId = Identifier.pipe(Schema.brand("EvaluationRunId"));
export type RunId = typeof RunId.Type;

export const BackendId = Identifier.pipe(Schema.brand("EvaluationBackendId"));
export type BackendId = typeof BackendId.Type;

export const InputContractId = Identifier.pipe(
  Schema.brand("EvaluationInputContractId"),
);
export type InputContractId = typeof InputContractId.Type;

export const RendererAdapterId = Identifier.pipe(
  Schema.brand("EvaluationRendererAdapterId"),
);
export type RendererAdapterId = typeof RendererAdapterId.Type;

export const Version = Identifier.pipe(Schema.brand("EvaluationVersion"));
export type Version = typeof Version.Type;

export const DigestRef = Schema.Struct({
  id: Identifier,
  version: Version,
  digest: EvaluationDigest,
});
export interface DigestRef extends Schema.Schema.Type<typeof DigestRef> {}

export const RuleIdentity = Schema.Struct({
  packId: RulePackId,
  ruleId: LocalRuleId,
  qualifiedId: QualifiedRuleId,
  packVersion: Version,
});
export interface RuleIdentity extends Schema.Schema.Type<typeof RuleIdentity> {}

export const RuleApplicability = Schema.Struct({
  includePatterns: Schema.Array(Schema.String),
  excludePatterns: Schema.Array(Schema.String),
});
export interface RuleApplicability
  extends Schema.Schema.Type<typeof RuleApplicability> {}

/** Production packs use the structured Noul criteria; string criteria remain
 * accepted for small authored fixtures and backwards-compatible model data. */
export const RuleCriteria = Schema.Union([
  Schema.NonEmptyString,
  Schema.Struct({
    false: Schema.NonEmptyString,
    true: Schema.NonEmptyString,
  }),
]);
export type RuleCriteria = typeof RuleCriteria.Type;

export const RuleDefinition = Schema.Struct({
  identity: RuleIdentity,
  question: Schema.NonEmptyString,
  criteria: RuleCriteria,
  defaultMessage: Schema.NonEmptyString,
  threshold: Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
  applicability: RuleApplicability,
  definitionDigest: EvaluationDigest,
});
export interface RuleDefinition extends Schema.Schema.Type<typeof RuleDefinition> {}

export const Fixture = Schema.Struct({
  id: FixtureId,
  name: Schema.NonEmptyString,
  role: Schema.Literals(["positive", "negative", "negative-control", "ambiguous"] as const),
  domain: Schema.NonEmptyString,
  path: Schema.NonEmptyString,
  source: Schema.String,
  contentHash: EvaluationDigest,
  fixtureDigest: EvaluationDigest,
});
export interface Fixture extends Schema.Schema.Type<typeof Fixture> {}

export const FixtureReference = Schema.Struct({
  id: FixtureId,
  domain: Schema.NonEmptyString,
  path: Schema.NonEmptyString,
  contentHash: EvaluationDigest,
  fixtureDigest: EvaluationDigest,
});
export interface FixtureReference
  extends Schema.Schema.Type<typeof FixtureReference> {}

export const RuleReference = Schema.Struct({
  qualifiedId: QualifiedRuleId,
  definitionDigest: EvaluationDigest,
});
export interface RuleReference extends Schema.Schema.Type<typeof RuleReference> {}

const ExpectedBandFields = Schema.Struct({
  minimum: Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
  maximum: Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
  minimumInclusive: Schema.Boolean,
  maximumInclusive: Schema.Boolean,
});
export const ExpectedBand = ExpectedBandFields.check(
  Schema.makeFilter((band) =>
    band.minimum < band.maximum ||
    (band.minimum === band.maximum &&
      band.minimumInclusive &&
      band.maximumInclusive)
      ? undefined
      : "minimum and maximum define an empty band",
  ),
);
export interface ExpectedBand extends Schema.Schema.Type<typeof ExpectedBand> {}

export const ExpectedResult = Schema.Union([
  Schema.Struct({
    kind: Schema.Literals(["clear", "violation"] as const),
    band: ExpectedBand,
  }),
  Schema.Struct({
    kind: Schema.Literal("ambiguous"),
    reason: Schema.NonEmptyString,
  }),
  Schema.Struct({
    kind: Schema.Literal("unchecked"),
    reason: Schema.NonEmptyString,
  }),
]);
export type ExpectedResult = typeof ExpectedResult.Type;

export const Expectation = Schema.Struct({
  fixtureId: FixtureId,
  ruleId: QualifiedRuleId,
  result: ExpectedResult,
  rationale: Schema.NonEmptyString,
  expectationDigest: EvaluationDigest,
});
export interface Expectation extends Schema.Schema.Type<typeof Expectation> {}

export const ConfigurationRuleOverride = Schema.Struct({
  ruleId: QualifiedRuleId,
  enabled: Schema.optionalKey(Schema.Boolean),
  threshold: Schema.optionalKey(
    Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
  ),
  message: Schema.optionalKey(Schema.NonEmptyString),
});
export interface ConfigurationRuleOverride
  extends Schema.Schema.Type<typeof ConfigurationRuleOverride> {}

export const ConfigurationLayer = Schema.Struct({
  name: Schema.Literals(["built-in", "user", "project"] as const),
  includePatterns: Schema.Array(Schema.String),
  excludePatterns: Schema.Array(Schema.String),
  ruleOverrides: Schema.Array(ConfigurationRuleOverride),
});
export interface ConfigurationLayer
  extends Schema.Schema.Type<typeof ConfigurationLayer> {}

export const ConsentState = Schema.Struct({
  repositoryId: Schema.NonEmptyString,
  backendId: BackendId,
  destinationId: Schema.NonEmptyString,
  granted: Schema.Boolean,
});
export interface ConsentState extends Schema.Schema.Type<typeof ConsentState> {}

export const ConfigurationProvenance = Schema.Struct({
  field: Schema.NonEmptyString,
  origin: Schema.Literals(["built-in", "user", "project"] as const),
  valueDigest: EvaluationDigest,
});
export interface ConfigurationProvenance
  extends Schema.Schema.Type<typeof ConfigurationProvenance> {}

export const EffectiveConfiguration = Schema.Struct({
  includePatterns: Schema.Array(Schema.String),
  excludePatterns: Schema.Array(Schema.String),
  selectedRuleIds: Schema.Array(QualifiedRuleId),
  ruleOverrides: Schema.Array(ConfigurationRuleOverride),
  provenance: Schema.Array(ConfigurationProvenance),
  configurationDigest: EvaluationDigest,
});
export interface EffectiveConfiguration
  extends Schema.Schema.Type<typeof EffectiveConfiguration> {}

export const ConfigurationCase = Schema.Struct({
  id: ConfigurationCaseId,
  builtIn: ConfigurationLayer,
  user: ConfigurationLayer,
  project: ConfigurationLayer,
  consent: ConsentState,
  expectedEffective: EffectiveConfiguration,
  caseDigest: EvaluationDigest,
});
export interface ConfigurationCase
  extends Schema.Schema.Type<typeof ConfigurationCase> {}

export const BackendIdentity = Schema.Struct({
  id: BackendId,
  version: Version,
  mode: Schema.Literals(["controlled", "fake-http", "live"] as const),
});
export interface BackendIdentity extends Schema.Schema.Type<typeof BackendIdentity> {}

export const InputContractIdentity = Schema.Struct({
  id: InputContractId,
  version: Version,
  digest: EvaluationDigest,
});
export interface InputContractIdentity
  extends Schema.Schema.Type<typeof InputContractIdentity> {}

export const RendererAdapterIdentity = Schema.Struct({
  id: RendererAdapterId,
  version: Version,
  digest: EvaluationDigest,
});
export interface RendererAdapterIdentity
  extends Schema.Schema.Type<typeof RendererAdapterIdentity> {}

export const ScenarioAction = Schema.Struct({
  kind: Schema.Literals([
    "observe-edit",
    "retry",
    "duplicate-event",
    "changed-snapshot",
    "backend-failure",
    "advance-time",
  ] as const),
  identity: Schema.NonEmptyString,
});
export interface ScenarioAction extends Schema.Schema.Type<typeof ScenarioAction> {}

const EvaluationScenarioFields = Schema.Struct({
  id: ScenarioId,
  name: Schema.NonEmptyString,
  interaction: Schema.Literals(["isolated", "full", "named"] as const),
  interactionName: Schema.optionalKey(Schema.NonEmptyString),
  fixtures: Schema.Array(FixtureReference),
  ruleSet: Schema.Array(RuleReference),
  configurationCaseId: ConfigurationCaseId,
  effectiveConfigurationDigest: EvaluationDigest,
  backend: BackendIdentity,
  inputContract: InputContractIdentity,
  rendererAdapter: RendererAdapterIdentity,
  eventSequence: Schema.Array(ScenarioAction),
  requestCount: Schema.optionalKey(NonNegativeInteger),
  scenarioDigest: EvaluationDigest,
});
/**
 * The wire shape intentionally remains compatible with the original public
 * object API, but the interaction mode is a checked variant: named scenarios
 * must carry a name and the other modes must not carry one.
 */
export const EvaluationScenario = EvaluationScenarioFields.check(
  Schema.makeFilter((scenario) => {
    const named = scenario.interaction === "named";
    const hasName = scenario.interactionName !== undefined;
    return named === hasName
      ? undefined
      : "interactionName is required only for named scenarios";
  }),
);
export interface EvaluationScenario
  extends Schema.Schema.Type<typeof EvaluationScenario> {}

export const AssessmentEntry = Schema.Struct({
  ruleId: QualifiedRuleId,
  probability: Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
});
export interface AssessmentEntry extends Schema.Schema.Type<typeof AssessmentEntry> {}

export const RequestShape = Schema.Struct({
  fixtureId: FixtureId,
  domain: Schema.NonEmptyString,
  path: Schema.NonEmptyString,
  contentHash: EvaluationDigest,
  ruleIds: Schema.Array(QualifiedRuleId),
  inputContract: InputContractIdentity,
  rendererAdapter: RendererAdapterIdentity,
});
export interface RequestShape extends Schema.Schema.Type<typeof RequestShape> {}

const TransportObservationFields = Schema.Struct({
  status: Schema.Literals(["available", "unavailable"] as const),
  attempts: PositiveInteger,
  retries: NonNegativeInteger,
  durationMs: NonNegativeFinite,
  errorCategory: Schema.optionalKey(Schema.NonEmptyString),
});
/** Available observations have no error category; unavailable observations
 * always retain a source-free category. Attempts are the initial request plus
 * the recorded retry count, so the aggregate budget is auditable. */
export const TransportObservation = TransportObservationFields.check(
  Schema.makeFilter((transport) => {
    if (transport.attempts !== transport.retries + 1) {
      return "attempts must equal retries plus one";
    }
    if (transport.status === "available" && transport.errorCategory !== undefined) {
      return "available transport cannot carry an error category";
    }
    if (transport.status === "unavailable" && transport.errorCategory === undefined) {
      return "unavailable transport requires an error category";
    }
    return undefined;
  }),
);
export interface TransportObservation
  extends Schema.Schema.Type<typeof TransportObservation> {}

export const ConformanceObservation = Schema.Struct({
  status: Schema.Literals(["passed", "failed", "unchecked"] as const),
  reasons: Schema.Array(Schema.NonEmptyString),
});
export interface ConformanceObservation
  extends Schema.Schema.Type<typeof ConformanceObservation> {}

export const FindingObservation = Schema.Struct({
  ruleId: QualifiedRuleId,
  probability: Schema.Finite.check(Schema.isBetween({ minimum: 0, maximum: 1 })),
  message: Schema.NonEmptyString,
});
export interface FindingObservation
  extends Schema.Schema.Type<typeof FindingObservation> {}

const ObservationFields = Schema.Struct({
  id: ObservationId,
  scenarioId: ScenarioId,
  fixtureId: FixtureId,
  repetition: PositiveInteger,
  request: RequestShape,
  transport: TransportObservation,
  conformance: ConformanceObservation,
  assessment: Schema.optionalKey(Schema.Array(AssessmentEntry)),
  findings: Schema.Array(FindingObservation),
  reviewStatus: Schema.Literals(["reviewed", "skipped", "unavailable", "incomplete"] as const),
  observationDigest: EvaluationDigest,
});
/**
 * Review status and assessment are one state machine, not independent flags.
 * Keep the existing fields for callers while rejecting combinations that could
 * make an unavailable or incomplete review look successfully assessed.
 */
export const Observation = ObservationFields.check(
  Schema.makeFilter((observation) => {
    const hasAssessment = observation.assessment !== undefined;
    switch (observation.reviewStatus) {
      case "reviewed":
        return observation.transport.status === "available" &&
            observation.conformance.status === "passed" &&
            hasAssessment
          ? undefined
          : "reviewed observations require available transport, passed conformance, and an assessment";
      case "unavailable":
        return observation.transport.status === "unavailable" &&
            observation.conformance.status === "unchecked" &&
            !hasAssessment
          ? undefined
          : "unavailable observations require unavailable transport, unchecked conformance, and no assessment";
      case "incomplete":
        return observation.transport.status === "available" &&
            observation.conformance.status === "failed" &&
            !hasAssessment
          ? undefined
          : "incomplete observations require available transport, failed conformance, and no assessment";
      case "skipped":
        return hasAssessment
          ? "skipped observations cannot carry an assessment"
          : undefined;
    }
  }),
);
export interface Observation extends Schema.Schema.Type<typeof Observation> {}

const ComparisonFields = Schema.Struct({
  id: ComparisonId,
  name: Schema.NonEmptyString,
  relation: Schema.Literals(["exact", "semantic-band", "measured-change"] as const),
  leftObservationId: Schema.optionalKey(ObservationId),
  rightObservationId: Schema.optionalKey(ObservationId),
  observationId: Schema.optionalKey(ObservationId),
  ruleId: Schema.optionalKey(QualifiedRuleId),
  expectation: Schema.optionalKey(Expectation),
  fixtureRelation: Schema.optionalKey(Schema.Literals(["identical", "transformed"] as const)),
  direction: Schema.optionalKey(
    Schema.Literals(["increase", "decrease", "change", "no-change"] as const),
  ),
  minimumDelta: Schema.optionalKey(NonNegativeFinite),
  tolerance: NonNegativeFinite,
  comparisonDigest: EvaluationDigest,
});
/** A comparison relation has a fixed set of endpoint/semantic fields.  The
 * checked variants preserve the pre-existing flat JSON shape while preventing
 * callers from silently constructing an unusable comparison. */
export const Comparison = ComparisonFields.check(
  Schema.makeFilter((comparison) => {
    const hasLeft = comparison.leftObservationId !== undefined;
    const hasRight = comparison.rightObservationId !== undefined;
    const hasObservation = comparison.observationId !== undefined;
    const hasRule = comparison.ruleId !== undefined;
    switch (comparison.relation) {
      case "exact":
        return hasLeft && hasRight && comparison.leftObservationId !== comparison.rightObservationId &&
            !hasObservation && !hasRule &&
            comparison.expectation === undefined &&
            comparison.fixtureRelation === undefined &&
            comparison.direction === undefined &&
            comparison.minimumDelta === undefined
          ? undefined
          : "exact comparisons require only distinct left and right observations";
      case "semantic-band":
        return hasObservation && hasRule && !hasLeft && !hasRight &&
            comparison.fixtureRelation === undefined &&
            comparison.direction === undefined &&
            comparison.minimumDelta === undefined &&
            (comparison.expectation === undefined ||
              comparison.ruleId === undefined ||
              comparison.ruleId === comparison.expectation.ruleId)
          ? undefined
          : "semantic-band comparisons require one observation and no pair fields";
      case "measured-change":
        return hasLeft && hasRight && comparison.leftObservationId !== comparison.rightObservationId &&
            hasRule && !hasObservation &&
            comparison.expectation === undefined
          ? undefined
          : "measured-change comparisons require left/right observations and a rule";
    }
  }),
);
export interface Comparison extends Schema.Schema.Type<typeof Comparison> {}

export const CallBudget = Schema.Struct({
  maximumRequests: PositiveInteger,
  maximumRetriesPerRequest: NonNegativeInteger,
  // A milestone may have no remaining authorization.  Keeping zero valid lets a
  // planner reject the run before a provider layer is acquired.
  authorizedRemainingCalls: Schema.optionalKey(NonNegativeInteger),
});
export interface CallBudget extends Schema.Schema.Type<typeof CallBudget> {}

/** Predeclared milestone release gate; it is part of run identity. */
export const ReleaseAcceptance = Schema.Struct({
  requireTransportAvailable: Schema.Boolean,
  requireConformance: Schema.Boolean,
  requireSemanticPass: Schema.Boolean,
  requireNoUnchecked: Schema.Boolean,
});
export interface ReleaseAcceptance
  extends Schema.Schema.Type<typeof ReleaseAcceptance> {}
export const EvaluationRun = Schema.Struct({
  id: RunId,
  name: Schema.NonEmptyString,
  suiteId: EvaluationId,
  scenarioIds: Schema.Array(ScenarioId),
  scenarioDigests: Schema.Array(EvaluationDigest),
  configurationCaseIds: Schema.Array(ConfigurationCaseId),
  configurationCaseDigests: Schema.Array(EvaluationDigest),
  fixtureDigests: Schema.Array(EvaluationDigest),
  ruleDefinitionDigests: Schema.Array(EvaluationDigest),
  expectationDigests: Schema.Array(EvaluationDigest),
  backend: BackendIdentity,
  inputContract: InputContractIdentity,
  rendererAdapter: RendererAdapterIdentity,
  repetitions: PositiveInteger,
  budget: CallBudget,
  acceptance: ReleaseAcceptance,
  liveOptIn: Schema.Boolean,
  runDigest: EvaluationDigest,
});
export interface EvaluationRun extends Schema.Schema.Type<typeof EvaluationRun> {}

const EvaluationPlanFields = Schema.Struct({
  runId: RunId,
  scenarioIds: Schema.Array(ScenarioId),
  repetitions: PositiveInteger,
  maximumAttemptsPerRequest: PositiveInteger,
  plannedRequests: NonNegativeInteger,
  worstCaseRequests: NonNegativeInteger,
  budgetMaximumRequests: PositiveInteger,
  permitted: Schema.Boolean,
  rejectionReason: Schema.optionalKey(
    Schema.Literals([
      "budget-exceeded",
      "live-opt-in-required",
      "live-credential-required",
      "live-authorization-required",
      "live-authorization-exceeds-limit",
    ] as const),
  ),
  planDigest: EvaluationDigest,
});
export const EvaluationPlan = EvaluationPlanFields.check(
  Schema.makeFilter((plan) => {
    if (plan.permitted && plan.rejectionReason !== undefined) {
      return "permitted plans cannot carry a rejection reason";
    }
    if (!plan.permitted && plan.rejectionReason === undefined) {
      return "rejected plans require a rejection reason";
    }
    if (plan.worstCaseRequests !== plan.plannedRequests * plan.maximumAttemptsPerRequest) {
      return "worstCaseRequests must include the declared retry ceiling";
    }
    return undefined;
  }),
);
export interface EvaluationPlan extends Schema.Schema.Type<typeof EvaluationPlan> {}

const ComparisonResultFields = Schema.Struct({
  comparisonId: ComparisonId,
  relation: Schema.Literals(["exact", "semantic-band", "measured-change"] as const),
  deterministic: Schema.Literals(["passed", "failed", "unchecked"] as const),
  transport: Schema.Literals(["available", "unavailable", "unchecked"] as const),
  conformance: Schema.Literals(["passed", "failed", "unchecked"] as const),
  semantic: Schema.Literals(["passed", "failed", "ambiguous", "unchecked"] as const),
  passed: Schema.Boolean,
  reason: Schema.optionalKey(Schema.NonEmptyString),
  delta: Schema.optionalKey(Schema.Finite),
});
export const ComparisonResult = ComparisonResultFields.check(
  Schema.makeFilter((result) => {
    if (result.relation === "exact" && result.semantic !== "unchecked") {
      return "exact comparison results cannot carry a semantic status";
    }
    if (result.relation !== "exact" && result.deterministic !== "unchecked") {
      return "non-exact comparison results cannot carry a deterministic status";
    }
    const expectedPassed = result.transport === "available" &&
      result.conformance === "passed" &&
      (result.relation === "exact"
        ? result.deterministic === "passed"
        : result.semantic === "passed");
    if (result.passed !== expectedPassed) {
      return "passed must agree with transport, conformance, and relation status";
    }
    if (result.relation !== "measured-change" && result.delta !== undefined) {
      return "delta is only valid for measured-change results";
    }
    return undefined;
  }),
);
export interface ComparisonResult extends Schema.Schema.Type<typeof ComparisonResult> {}

const AggregateCountsFields = Schema.Struct({
  total: NonNegativeInteger,
  passed: NonNegativeInteger,
  failed: NonNegativeInteger,
  unchecked: NonNegativeInteger,
  ambiguous: NonNegativeInteger,
});
export const AggregateCounts = AggregateCountsFields.check(
  Schema.makeFilter((counts) =>
    counts.total === counts.passed + counts.failed + counts.unchecked + counts.ambiguous
      ? undefined
      : "aggregate total must equal the sum of its statuses",
  ),
);
export interface AggregateCounts extends Schema.Schema.Type<typeof AggregateCounts> {}

const ComparisonSummaryFields = Schema.Struct({
  id: ComparisonId,
  relation: Schema.Literals(["exact", "semantic-band", "measured-change"] as const),
  passed: Schema.Boolean,
  deterministic: Schema.Literals(["passed", "failed", "unchecked"] as const),
  transport: Schema.Literals(["available", "unavailable", "unchecked"] as const),
  conformance: Schema.Literals(["passed", "failed", "unchecked"] as const),
  semantic: Schema.Literals(["passed", "failed", "ambiguous", "unchecked"] as const),
  reason: Schema.optionalKey(Schema.NonEmptyString),
  delta: Schema.optionalKey(Schema.Finite),
});
export const ComparisonSummary = ComparisonSummaryFields.check(
  Schema.makeFilter((summary) => {
    if (summary.relation === "exact" && summary.semantic !== "unchecked") {
      return "exact comparison summaries cannot carry a semantic status";
    }
    if (summary.relation !== "exact" && summary.deterministic !== "unchecked") {
      return "non-exact comparison summaries cannot carry a deterministic status";
    }
    const expectedPassed = summary.transport === "available" &&
      summary.conformance === "passed" &&
      (summary.relation === "exact"
        ? summary.deterministic === "passed"
        : summary.semantic === "passed");
    if (summary.passed !== expectedPassed) {
      return "passed must agree with transport, conformance, and relation status";
    }
    if (summary.relation !== "measured-change" && summary.delta !== undefined) {
      return "delta is only valid for measured-change summaries";
    }
    return undefined;
  }),
);
export interface ComparisonSummary extends Schema.Schema.Type<typeof ComparisonSummary> {}

export const EvaluationCoverage = Schema.Struct({
  plannedScenarios: NonNegativeInteger,
  observedScenarios: NonNegativeInteger,
  plannedFixtures: NonNegativeInteger,
  observedFixtures: NonNegativeInteger,
  isolatedScenarios: NonNegativeInteger,
  fullBatchScenarios: NonNegativeInteger,
  namedInteractionScenarios: NonNegativeInteger,
  plannedComparisons: NonNegativeInteger,
  observedComparisons: NonNegativeInteger,
  plannedExpectations: NonNegativeInteger,
  observedExpectations: NonNegativeInteger,
  uncheckedExpectations: NonNegativeInteger,
  ambiguousExpectations: NonNegativeInteger,
});
export interface EvaluationCoverage extends Schema.Schema.Type<typeof EvaluationCoverage> {}

/**
 * Sanitized timing evidence for a run.  Only aggregate values cross the report
 * boundary; individual provider durations remain observation-local.
 */
const TimingEvidenceFields = Schema.Struct({
  sampleCount: NonNegativeInteger,
  totalDurationMs: NonNegativeFinite,
  minimumDurationMs: NonNegativeFinite,
  maximumDurationMs: NonNegativeFinite,
  meanDurationMs: NonNegativeFinite,
  p50DurationMs: NonNegativeFinite,
  p95DurationMs: NonNegativeFinite,
});
export const EvaluationTimingEvidence = TimingEvidenceFields.check(
  Schema.makeFilter((timing) => {
    if (timing.sampleCount === 0) {
      return timing.totalDurationMs === 0 &&
          timing.minimumDurationMs === 0 &&
          timing.maximumDurationMs === 0 &&
          timing.meanDurationMs === 0 &&
          timing.p50DurationMs === 0 &&
          timing.p95DurationMs === 0
        ? undefined
        : "empty timing evidence must contain zero aggregates";
    }
    if (timing.minimumDurationMs > timing.maximumDurationMs ||
        timing.p50DurationMs < timing.minimumDurationMs ||
        timing.p50DurationMs > timing.maximumDurationMs ||
        timing.p95DurationMs < timing.p50DurationMs ||
        timing.p95DurationMs > timing.maximumDurationMs) {
      return "timing percentiles must be ordered within the observed range";
    }
    return Math.abs(timing.meanDurationMs * timing.sampleCount - timing.totalDurationMs) <
        Math.max(1e-9, timing.totalDurationMs * 1e-9)
      ? undefined
      : "timing mean must agree with total duration and sample count";
  }),
);
export interface EvaluationTimingEvidence
  extends Schema.Schema.Type<typeof EvaluationTimingEvidence> {}

const RejectionReason = Schema.Literals([
  "budget-exceeded",
  "live-opt-in-required",
  "live-credential-required",
  "live-authorization-required",
  "live-authorization-exceeds-limit",
] as const);

const EvaluationBudgetSummaryFields = Schema.Struct({
  declaredMaximumRequests: PositiveInteger,
  plannedRequests: NonNegativeInteger,
  worstCaseRequests: NonNegativeInteger,
  observedRequests: NonNegativeInteger,
  withinBudget: Schema.Boolean,
  planPermitted: Schema.Boolean,
  rejectionReason: Schema.optionalKey(RejectionReason),
});
const EvaluationBudgetSummary = EvaluationBudgetSummaryFields.check(
  Schema.makeFilter((budget) => {
    if (budget.planPermitted && budget.rejectionReason !== undefined) {
      return "permitted reports cannot carry a rejection reason";
    }
    if (!budget.planPermitted && budget.rejectionReason === undefined) {
      return "rejected reports require a rejection reason";
    }
    const expectedWithinBudget = budget.observedRequests <= budget.declaredMaximumRequests &&
      budget.worstCaseRequests <= budget.declaredMaximumRequests;
    return budget.withinBudget === expectedWithinBudget
      ? undefined
      : "withinBudget must agree with observed and worst-case request counts";
  }),
);

export const EvaluationReport = Schema.Struct({
  runId: RunId,
  suiteId: EvaluationId,
  runDigest: EvaluationDigest,
  planDigest: EvaluationDigest,
  budget: EvaluationBudgetSummary,
  acceptance: ReleaseAcceptance,
  releaseAccepted: Schema.Boolean,
  deterministic: AggregateCounts,
  transport: AggregateCounts,
  conformance: AggregateCounts,
  semantic: AggregateCounts,
  crossBatch: AggregateCounts,
  unchecked: AggregateCounts,
  timing: EvaluationTimingEvidence,
  coverage: EvaluationCoverage,
  comparisons: Schema.Array(ComparisonSummary),
  fixtureDigests: Schema.Array(EvaluationDigest),
  ruleDefinitionDigests: Schema.Array(EvaluationDigest),
  expectationDigests: Schema.Array(EvaluationDigest),
  configurationCaseIds: Schema.Array(ConfigurationCaseId),
  configurationCaseDigests: Schema.Array(EvaluationDigest),
  inputContract: InputContractIdentity,
  rendererAdapter: RendererAdapterIdentity,
  reportDigest: EvaluationDigest,
});
export interface EvaluationReport extends Schema.Schema.Type<typeof EvaluationReport> {}

/** Strict parsing options are exported so every boundary can reject unknown fields. */
export const strictParseOptions = {
  onExcessProperty: "error",
  errors: "all",
} as const;

export const decodeRuleDefinition = Schema.decodeUnknownEffect(
  RuleDefinition,
  strictParseOptions,
);
export const decodeFixture = Schema.decodeUnknownEffect(Fixture, strictParseOptions);
export const decodeExpectation = Schema.decodeUnknownEffect(
  Expectation,
  strictParseOptions,
);
export const decodeConfigurationCase = Schema.decodeUnknownEffect(
  ConfigurationCase,
  strictParseOptions,
);
export const decodeEvaluationScenario = Schema.decodeUnknownEffect(
  EvaluationScenario,
  strictParseOptions,
);
export const decodeEvaluationPlan = Schema.decodeUnknownEffect(
  EvaluationPlan,
  strictParseOptions,
);
export const decodeObservation = Schema.decodeUnknownEffect(
  Observation,
  strictParseOptions,
);
export const decodeComparison = Schema.decodeUnknownEffect(
  Comparison,
  strictParseOptions,
);
export const decodeComparisonResult = Schema.decodeUnknownEffect(
  ComparisonResult,
  strictParseOptions,
);
export const decodeEvaluationRun = Schema.decodeUnknownEffect(
  EvaluationRun,
  strictParseOptions,
);
export const decodeEvaluationReport = Schema.decodeUnknownEffect(
  EvaluationReport,
  strictParseOptions,
);

/** A conservative check used by the pure digest functions. */
export const isFiniteProbability = (value: number): value is Probability =>
  Number.isFinite(value) && value >= 0 && value <= 1;
