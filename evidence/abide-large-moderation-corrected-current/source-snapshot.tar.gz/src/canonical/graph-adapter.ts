import { bendImportGraphInitial, bendImportGraphStep, bendImportGraphLocalBudget } from "./import-graph.generated.js";
import { GRAPH_LIMIT_CEILINGS, validateGraphLimits, type GraphLimits } from "../configuration/graph-limits.ts";
export { GRAPH_LIMIT_CEILINGS, validateGraphLimits, type GraphLimits } from "../configuration/graph-limits.ts";

export type { ImportGraphEvent, ImportGraphCommand, ImportGraphProjection } from "./graph-schema.ts";
import { decodeGraphEvent, decodeGraphState, decodeGraphStep, decodeGraphEdge, decodeGraphProfile, decodeNativeNatural, type ImportGraphEvent, type ImportGraphCommand, type ImportGraphProjection } from "./graph-schema.ts";
import { readNat, readBendList, readRecord } from "./boundary-schema.ts";
import { freezeCanonicalData } from "./immutable.ts";
const nat = readNat;
const list = (items: readonly number[]): unknown =>
  items.reduceRight<unknown>((tail, head) => ({ $: "Con", head, tail }), { $: "Nil" });
const readList = <T>(value: unknown, decode: (value: unknown) => T): T[] =>
  readBendList(value, decode, 128);
const encode = (input: ImportGraphEvent): unknown => {
  const event = decodeGraphEvent(input);
  switch (event.kind) {
    case "root": return { $: "ImportGraph.Root", target: event.target, source_bytes: event.sourceBytes, tree_bytes: event.treeBytes, local_work: event.localWork ?? 0, edges: list(event.edges) };
    case "next": return { $: "ImportGraph.Next" };
    case "resolved": return { $: "ImportGraph.Resolved", target: event.target, result: { $: ({ found: "ImportGraph.Found", missing: "ImportGraph.NotFound", ambiguous: "ImportGraph.Many", unsupported: "ImportGraph.Unhandled" } as const)[event.result] } };
    case "pathChecked": return { $: "ImportGraph.PathChecked", allowed: event.allowed };
    case "captured": return { $: "ImportGraph.Captured", source_bytes: event.sourceBytes, node_bytes: event.treeBytes, local_work: event.localWork ?? 0, edges: list(event.edges) };
    case "captureFailed": return { $: "ImportGraph.CaptureFailed" };
    case "deadlineReached": return { $: "ImportGraph.DeadlineReached" };
  }
};
const reason = (value: { readonly $: string }): string => value.$.replace("ImportGraph.", "");
const command = (value: ReturnType<typeof decodeGraphStep>["command"]): ImportGraphCommand => {
  switch (value.$) {
    case "NoCommand": case "ImportGraph.NoCommand": return { kind: "none" };
    case "ResolveEdge": case "ImportGraph.ResolveEdge": return { kind: "resolveEdge", edge: value.edge };
    case "CheckPath": case "ImportGraph.CheckPath": return { kind: "checkPath", target: value.target };
    case "ReadSource": case "ImportGraph.ReadSource": return { kind: "readSource", target: value.target };
    case "UnitComplete": case "ImportGraph.UnitComplete": return { kind: "unitComplete" };
    case "UnitIncomplete": case "ImportGraph.UnitIncomplete": return { kind: "unitIncomplete", reason: reason(value.reason) };
    case "SkipImport": case "ImportGraph.SkipImport": return { kind: "skipImport", target: value.target, reason: reason(value.reason) };
  }
};
const phases = { Idle: "idle", Ready: "ready", Resolving: "resolving", Checking: "checking", Capturing: "capturing", Complete: "complete", Incomplete: "incomplete" } as const;
const projections = new WeakMap<object, ImportGraphProjection>();
export const projectImportGraph = (state: unknown): ImportGraphProjection => {
  // Copies continue through full decoding; only registered frozen objects are memoized.
  if (typeof state === "object" && state !== null) {
    const cached = projections.get(state);
    if (cached !== undefined) return cached;
  }
  const { graph: object } = decodeGraphState(state);
  const name = object.phase.$.replace(/^ImportGraph\./, "") as keyof typeof phases;
  const phase = phases[name];
  const raw = object.limits;
  const limits = decodeGraphProfile({ version: raw.version,
    sourceBytes: raw.source_bytes, treeBytes: raw.tree_bytes,
    files: raw.files, readBytes: raw.read_bytes,
    outgoingEdges: raw.outgoing_edges, depth: raw.depth, work: raw.work });
  return freezeCanonicalData({ limits, phase, ...("reason" in object.phase ? { reason: reason(object.phase.reason) } : {}),
    pending: readList(object.pending, (edge) => decodeGraphEdge(edge).id),
    visited: readList(object.visited, decodeNativeNatural), files: object.files, readBytes: object.read_bytes,
    treeBytes: object.tree_bytes, work: object.work, skippedTree: object.skipped_tree,
    skippedExcluded: object.skipped_excluded, skippedOther: object.skipped_other });
};
export const initialImportGraph = (limits: GraphLimits = GRAPH_LIMIT_CEILINGS): unknown => {
  const effective = validateGraphLimits(limits);
  const state = bendImportGraphInitial({
    $: "ImportGraph.Limits", version: nat(effective.version),
    source_bytes: nat(effective.sourceBytes), tree_bytes: nat(effective.treeBytes),
    files: nat(effective.files), read_bytes: nat(effective.readBytes),
    outgoing_edges: nat(effective.outgoingEdges), depth: nat(effective.depth), work: nat(effective.work),
  });
  const projection = projectImportGraph(state);
  const identity = freezeCanonicalData(readRecord(state));
  projections.set(identity, projection);
  return identity;
};

/** Bend checks native local-reference facts against the same frozen graph profile. */
export const permitLocalGraphFacts = (limits: GraphLimits, localWork: number,
  localDepth: number, distinctTargets: number, graphWork: number): boolean => {
  const effective = validateGraphLimits(limits);
  return bendImportGraphLocalBudget({
    $: "ImportGraph.Limits", version: nat(effective.version),
    source_bytes: nat(effective.sourceBytes), tree_bytes: nat(effective.treeBytes),
    files: nat(effective.files), read_bytes: nat(effective.readBytes),
    outgoing_edges: nat(effective.outgoingEdges), depth: nat(effective.depth), work: nat(effective.work),
  }, nat(localWork), nat(localDepth), nat(distinctTargets), nat(graphWork));
};
export const stepImportGraph = (state: unknown, event: ImportGraphEvent): { readonly state: unknown; readonly command: ImportGraphCommand } => {
  projectImportGraph(state);
  const raw = decodeGraphStep(bendImportGraphStep(state, encode(event)));
  const projection = projectImportGraph(raw.state);
  const identity = freezeCanonicalData(readRecord(raw.state));
  projections.set(identity, projection);
  return { state: identity, command: command(raw.command) };
};
