import * as Effect from "effect/Effect";
import { execFileClosedStdin, spawnInherited } from "./host-process.ts";
import * as Schema from "effect/Schema";
import * as Config from "effect/Config";
import { homedir } from "node:os";
import { isAbsolute, join, resolve } from "node:path";
import { readFileSync, realpathSync } from "node:fs";
import { atomicInstallationFile } from "./atomic-installation-file.ts";
import { hasClaudeRegistration } from "./claude-installation.ts";
import { hasCodexRegistration } from "./codex-installation.ts";
import type { SetupClient } from "./client-selection.ts";

export const clientCommands = ["setup", "update", "doctor", "repair", "reinstall", "uninstall"] as const;
export type ClientCommand = typeof clientCommands[number];
export const clients: ReadonlyArray<SetupClient> = ["claude", "codex"];
export const profileFields = (host: SetupClient, flags: ReadonlyMap<string, string>) => {
  const home = flags.get(`--${host}-home`);
  const executable = flags.get(`--${host}-executable`);
  return host === "claude"
    ? { host, ...(home === undefined ? {} : { claudeHome: home }), ...(executable === undefined ? {} : { claudeExecutable: executable }) }
    : { host, ...(home === undefined ? {} : { codexHome: home }), ...(executable === undefined ? {} : { codexExecutable: executable }) };
};
export const registeredClients = (flags: ReadonlyMap<string, string>, onError?: (host: SetupClient, cause: unknown) => void): SetupClient[] => clients.filter(host => {
  try {
    const fields = profileFields(host, flags);
    return fields.host === "claude" ? hasClaudeRegistration(fields) : hasCodexRegistration(fields);
  } catch (cause) { if (onError === undefined) throw cause; onError(host, cause); return false; }
});

const ActivePackage = Schema.Struct({ version: Schema.Literal(1), executable: Schema.NonEmptyString, runtime: Schema.NonEmptyString, entrypoint: Schema.NonEmptyString });
const PackageIdentity = Schema.Struct({ name: Schema.Literal("@hapsland/hapsland"), runtime: Schema.NonEmptyString, entrypoint: Schema.NonEmptyString });
const activePath = () => join(homedir(), ".local", "share", "hapsland", "active.json");
class PackageLifecycleError extends Schema.TaggedError<PackageLifecycleError>()("PackageLifecycleError", {
  message: Schema.NonEmptyString,
}) {}
const nativePackageObservation = Effect.fn("PackageLifecycle.observe")(<A>(message: string, read: () => A) =>
  Effect.try({ try: read, catch: () => new PackageLifecycleError({ message }) }));
export const activateCurrentPackage = Effect.fn("PackageLifecycle.activateCurrent")((entrypoint: string) =>
  nativePackageObservation("Activating the current public CLI failed. Keep the package and retry setup.", () =>
    atomicInstallationFile(activePath(), JSON.stringify({ version: 1, executable: entrypoint, runtime: process.execPath, entrypoint }) + "\n")));
export const activatePackage = Effect.fn("PackageLifecycle.activate")(function* (executable: string) {
  const message = "The updated hooks are installed, but activating the public CLI failed. Keep the target package and retry update.";
  const absolute = yield* nativePackageObservation(message, () => { const path = resolve(executable); realpathSync(path); return path; });
  const result = yield* execFileClosedStdin(absolute, ["--package-identity"], {
    timeout: 10_000, maxBuffer: 1_048_576, env: { ...process.env, HAPSLAND_ACTIVE_DISPATCH: "1" },
  });
  if (!result.succeeded) return yield* Effect.fail(new PackageLifecycleError({ message }));
  const identity = yield* nativePackageObservation(message, (): unknown => JSON.parse(result.stdout)).pipe(
    Effect.flatMap(Schema.decodeUnknownEffect(PackageIdentity)),
    Effect.mapError(() => new PackageLifecycleError({ message })),
  );
  if (!isAbsolute(identity.runtime) || !isAbsolute(identity.entrypoint)) {
    return yield* Effect.fail(new PackageLifecycleError({ message: "Target package identity paths must be absolute." }));
  }
  yield* nativePackageObservation(message, () => atomicInstallationFile(activePath(), JSON.stringify({
    version: 1, executable: absolute, runtime: identity.runtime, entrypoint: identity.entrypoint,
  }) + "\n"));
});
const dispatchEnvironment = () => {
  const environment: NodeJS.ProcessEnv = { ...process.env, HAPSLAND_ACTIVE_DISPATCH: "1" };
  delete environment.REVIEW_INSTALL_RUNTIME;
  delete environment.REVIEW_INSTALL_ENTRYPOINT;
  return environment;
};
/** Explicit package selection overrides the active administrative package. */
export const dispatchSelectedPackage = Effect.fn("PackageLifecycle.dispatchSelected")(function* (
  executable: string, command: ClientCommand, host: SetupClient | undefined, flags: ReadonlyMap<string, string>,
) {
  const args = [command, ...(host === undefined ? [] : [host]), ...[...flags].filter(([name]) => name !== "--target" && name !== "--host").map(([name, value]) => `${name}=${value}`)];
  const result = yield* spawnInherited(resolve(executable), args, dispatchEnvironment());
  if (!result.started) return yield* Effect.fail(new PackageLifecycleError({ message: `Selected package cannot run: ${executable}.` }));
  return result.exitCode ?? 6;
});
const readActivePackage = (args: ReadonlyArray<string>): typeof ActivePackage.Type | undefined => {
  try {
    const active = Schema.decodeUnknownSync(ActivePackage)(JSON.parse(readFileSync(activePath(), "utf8")));
    if (![active.executable, active.runtime, active.entrypoint].every(isAbsolute)) throw new Error("active package paths must be absolute");
    return active;
  } catch (cause) {
    if (typeof cause === "object" && cause !== null && "code" in cause && cause.code === "ENOENT") return undefined;
    if (args[0] === "reinstall") { process.stderr.write("Active-package record is damaged; reinstalling from PATH.\n"); return undefined; }
    throw new PackageLifecycleError({ message: "Hapsland active-package record is damaged. Run hapsland reinstall to rebuild it from the package in PATH." });
  }
};
/** Only public lifecycle commands dispatch. Hook processes and JSON automation stay pinned. */
export const dispatchActivePackage = Effect.fn("PackageLifecycle.dispatchActive")(function* (args: ReadonlyArray<string>) {
  const dispatched = yield* Config.NonEmptyString("HAPSLAND_ACTIVE_DISPATCH").pipe(Config.withDefault("0"),
    Effect.mapError(() => new PackageLifecycleError({ message: "Active package dispatch configuration is invalid." })));
  if (dispatched === "1") return undefined;
  const active = yield* Effect.try({ try: () => readActivePackage(args),
    catch: (cause) => cause instanceof PackageLifecycleError ? cause : new PackageLifecycleError({ message: "Reading the active package failed." }) });
  if (active === undefined) return undefined;
  const current = yield* nativePackageObservation(`Active package is unavailable: ${active.entrypoint}. Run hapsland reinstall to restore hooks from the package in PATH.`, () => {
    try {
      return realpathSync(process.argv[1] ?? "") === realpathSync(active.entrypoint) && realpathSync(process.execPath) === realpathSync(active.runtime);
    } catch {
      if (args[0] === "reinstall") { process.stderr.write("Active package is unavailable; reinstalling from the package in PATH.\n"); return undefined; }
      throw new Error("active package paths unavailable");
    }
  });
  if (current !== false) return undefined;
  const result = yield* spawnInherited(active.runtime, [active.entrypoint, ...args], dispatchEnvironment());
  if (!result.started) return yield* Effect.fail(new PackageLifecycleError({ message: `Active package cannot run: ${active.executable}. Restore that package or remove ~/.local/share/hapsland/active.json and run hapsland reinstall.` }));
  return result.exitCode ?? 6;
});

const record = (value: unknown): Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : {};
export const formatCompatibility = (value: unknown): string[] => {
  const lines: string[] = [];
  const walk = (node: unknown, path: string) => {
    const item = record(node);
    if (item.required !== undefined) lines.push(`${path}: detected ${typeof item.observed === "string" ? item.observed : "unavailable"}; required ${String(item.required)}.`);
    else for (const [key, child] of Object.entries(item)) if (typeof child === "object") walk(child, path ? `${path} ${key}` : key);
  };
  walk(value, "Compatibility");
  return lines;
};
export const formatProposal = (value: unknown): string[] => {
  const proposal = record(value);
  const lines: string[] = [];
  const current = record(proposal.current); const target = record(proposal.target);
  if (target.packageVersion !== undefined) lines.push(`Version: ${String(current.packageVersion ?? "unrecorded")} → ${String(target.packageVersion)}.`);
  if (Array.isArray(proposal.changes)) for (const change of proposal.changes) {
    const item = record(change);
    lines.push(`${String(item.description ?? "Owned configuration change")}${(item.path ?? item.file) === undefined ? "" : `: ${String(item.path ?? item.file)}`}.`);
  }
  const journal = record(proposal.journalReplacement);
  if (journal.file !== undefined) lines.push(`Back up interrupted journal ${String(journal.file)} and rebuild using current settings.`);
  const owned = record(proposal.ownedChanges);
  const hooks = record(owned.hooks ?? owned.hook ?? target.hook);
  const groups = record(hooks.groups);
  for (const [event, value] of Object.entries(groups)) {
    const group = record(value);
    lines.push(`${event}${group.matcher === undefined ? "" : ` (${String(group.matcher)})`}${hooks.file === undefined ? "" : ` in ${String(hooks.file)}`}:`);
    if (Array.isArray(group.hooks)) for (const handler of group.hooks) {
      const item = record(handler);
      lines.push(`  ${item.async === true ? "background" : "foreground"}, timeout ${String(item.timeout)}s: ${String(item.command)}`);
    }
  }
  return lines;
};
export const formatDoctor = (value: unknown, host: SetupClient): string[] => {
  const result = record(value);
  const lines = [`${host}: ${String(result.status ?? "check failed")}.`];
  if (Array.isArray(result.checks)) for (const value of result.checks) {
    const check = record(value);
    lines.push(`  ${String(check.stage)}: ${check.stage === "configuration-ownership" && check.status === "conflict" ? "installation damaged" : String(check.status)}.`);
    if (check.status !== "ready") {
      if (typeof check.observed === "string") lines.push(`    ${check.observed}`);
      const detail = record(record(check.observed).error).message;
      if (typeof detail === "string") lines.push(`    ${detail}`);
      lines.push(...formatCompatibility(check.observed).map(line => `    ${line}`));
      if (typeof check.action === "string") lines.push(`    Next: ${check.action}`);
    }
    if (check.stage === "configuration-ownership" && check.status !== "ready") lines.push(`    Run hapsland repair ${host}; for changed Hapsland entries, use hapsland reinstall ${host}.`);
  }
  lines.push("Native trust and actual agent execution must be checked in the client.");
  return lines;
};
export const formatFailure = (value: unknown, host: SetupClient): string => {
  const result = record(value); const error = record(result.error);
  const message = String(error.message ?? result.status ?? "operation failed");
  if (message.includes("explicitly disabled")) return `${host}: ${message}. Enable features.hooks in the selected Codex config only if your policy permits Hapsland hooks, then rerun setup.`;
  return `${host}: ${String(error.message ?? result.status ?? "operation failed")}. Files were preserved where ownership could not be established. Run hapsland doctor ${host}; use hapsland reinstall ${host} to replace marked Hapsland hooks. Malformed configuration must be corrected first.`;
};

const LifecycleResult = Schema.Struct({
  status: Schema.String,
  alreadyCurrent: Schema.optionalKey(Schema.Boolean),
  error: Schema.optionalKey(Schema.Unknown),
  host: Schema.optionalKey(Schema.Unknown),
  recovery: Schema.optionalKey(Schema.Unknown),
  proposal: Schema.optionalKey(Schema.Struct({
    digest: Schema.String.check(Schema.isPattern(/^[a-f0-9]{64}$/)),
    changes: Schema.optionalKey(Schema.Array(Schema.Unknown)),
    ownedChanges: Schema.optionalKey(Schema.Unknown),
    current: Schema.optionalKey(Schema.Unknown),
    target: Schema.optionalKey(Schema.Unknown),
    journalReplacement: Schema.optionalKey(Schema.Unknown),
  })),
});
export class LifecycleInvocationError extends Schema.TaggedError<LifecycleInvocationError>()("LifecycleInvocationError", {
  message: Schema.String,
}) {}
/** Every human mutation uses the same checked preview/apply transport. */
export const invokeLifecycle = Effect.fn("ClientLifecycle.invoke")(function* (
  command: string, args: ReadonlyArray<string>, host: SetupClient, request: unknown,
  environment: NodeJS.ProcessEnv = process.env,
) {
  const input = yield* Effect.try({ try: () => {
    const encoded = JSON.stringify(request);
    if (encoded === undefined) throw new Error("missing lifecycle request");
    return encoded;
  }, catch: () => new LifecycleInvocationError({ message: `${host}: lifecycle request could not be encoded` }) });
  const result = yield* execFileClosedStdin(command, args, { input, env: environment,
    timeout: 30_000, maxBuffer: 1024 * 1024 });
  if (result.timedOut) return yield* Effect.fail(new LifecycleInvocationError({
    message: `${host}: lifecycle request deadline exceeded; outcome is uncertain`,
  }));
  const unreadable = () => new LifecycleInvocationError({
    message: `${host}: package returned an unreadable lifecycle result. Run hapsland doctor ${host}.`,
  });
  const parsed = yield* Effect.try({ try: () => JSON.parse(result.stdout), catch: unreadable });
  const output = yield* Schema.decodeUnknownEffect(LifecycleResult)(parsed).pipe(Effect.mapError(unreadable));
  if (!result.succeeded && output.status !== "partial") {
    const compatibility = formatCompatibility(record(output.host).compatibility);
    return yield* Effect.fail(new LifecycleInvocationError({ message: [formatFailure(output, host), ...compatibility].join("\n") }));
  }
  return output;
});
