# Bend architecture tower defense

**Purpose:** Explore a native Bend tower-defense game in which architectural queues appear as safe approach roads and dangerous building arrivals, with generic scenario configuration and construction mechanics.
**Status:** Throwaway gameplay prototype; see validation evidence for executed checks.
**Authority:** Implementation and validation evidence, not an accepted Hapsland product contract.
**Expected use:** Play the road/building tower-defense prototype locally on macOS or Linux, reproduce its mechanics checks, and use the retained queue-board and combat experiments as diagnostic comparisons.
**Lifecycle:** At the tower-defense direction decision milestone, consolidate useful mechanics and evidence into its owning game specification or issue, update inbound links, and delete rejected prototype code and temporary evidence. Preserve provenance in the isolated prototype worktree/branch or source bundle. Revisit these instructions when native controls or the tested Bend version change.

## Current direction: roads, buildings and construction

The main playable direction is again tower defense. Run `./run-road.sh` for a native map with incoming enemies, roads, architectural buildings and player-built processing towers. The queue-board experiment below remains available as a diagnostic view rather than replacing the game genre.

An architectural queue owns one persistent packet identity throughout its approach road and building. On the road, the packet is safe. At the building it starts contributing recurring damage until it leaves that queue. More arrived packets mean more pressure. A packet held after computation or blocked from entering the next queue still occupies its building and contributes pressure; speeding computation cannot erase retained-resource costs.

Architectural buildings naturally process work. Player-built towers accelerate arrived work within their physical range; construction, placement, tower type, upgrades and admission pacing are the player decisions. Finishing processing sends an identified enemy into the configured next queue instead of killing it. Clear outcomes take their configured terminal route; finding-bearing work continues through advice and output.

`RoadModel.bend` defines generic geometry, capacities, processing/holding requirements and state. `RoadGame.bend` owns movement, construction, range, processing, pressure, transfers and economy. `RoadScenario.bend` supplies stage names, routes and numeric scenario assumptions. `RoadRender.bend` draws the map from that configuration; `RoadMain.bend` hosts native input and fixed twenty-millisecond timing. All authored gameplay and rendering are Bend. The shell launcher only compiles and starts the executable.

The model separates **safe road travel**, **dangerous building occupancy**, and **terminal coverage loss**. A refusal costs one health separately from recurring building pressure. A missed wave deadline fails the run and records unserved authored demand as lost. Neither is reclassified as recurring road damage. Ordinary full destinations wait on their road or retain an upstream reservation; immediate destinations retain the scenario's refusal policy.

For a packet travelling a road of length L at speed v, approach slack is approximately `ceil(L/v)` ticks. It delays both danger and useful processing. It does not increase service capacity. The recurring damage calculation is:

```text
hot(t) = number of packets inside architectural buildings at tick t
pressure += hot(t)
damage = pressure // pressureEvery
pressure = pressure % pressureEvery
```

This makes the area under building occupancy the quantity to minimize. Road occupancy contributes zero to this integral. Capacity, coverage, construction cost and finish latency must still be assessed separately: a policy that delays all work is not rewarded for simply hiding pressure on the road.

The Hapsland mapping is a teaching scenario, not a production canonical replay. Queue names, road geometry, capacities, work requirements, holding durations and route changes belong in scenario configuration. New transition semantics still require a deliberate engine extension. No production dispatch or delivery behavior changes with this game.

## Play architecture tower defense

With Bend and native compiler prerequisites installed, run `./run-road.sh` from this directory. The launcher builds for your own computer; a Linux executable is not a macOS executable.

- **1 Rapid**, **2 Batch**, **3 Relay** choose a processing building. Their construction costs are 35, 55 and 45 gold.
- **Click ground** to construct; **click an existing processor** to select it; **U** upgrades the selection. The placement ghost and range circle use the same legality/range functions as the mechanics.
- **N / Enter** starts a wave. **[ / ]** admit faster/slower; the HUD shows the interval in milliseconds.
- **Space / P** pauses; **R** restarts; **Tab** selects the next scenario and resets; **Escape** closes the window.

The four contexts are the default, capture pressure, review pressure and output retention. Architectural warehouse anchors and their incoming roads come from configuration. Constructed processing buildings have their own physical position, level and range. Moving enemies preserve their identity; blue/gold enemies on roads are safe, while red crowds at buildings cause recurring pressure. Processing bars show remaining effort; an H/hold bar marks retained output that continues to cause pressure. The green EXIT marker denotes a configured terminal route.

Six waves offer 24, 30, 36, 42, 48 and 54 immutable demand identities, for 234 total. Two of every three identities carry a finding. Each wave has forty seconds to complete, not just to admit demand. At the deadline the run fails and unoffered remaining demand is counted as lost; the HUD distinguishes deadline failure from zero-health building overload. Base buildings work even without construction, but their dangerous occupancy still costs health.

The model makes each site a finite-capacity building plus a finite safe road. A full ordinary building stops approach at its entrance; a full immediate-refusal building records one drop and one health cost. A full downstream road keeps completed work inside its source building, still dangerous. Tower beams subtract processing work from arrived enemies, preserving identity and outcome class. Towers do not shorten configured holding time.

The renderer packs arrived enemies around a warehouse so a crowd remains visible. This is drawing-only placement: range checks and processing beams target the configured building center. Safe road positions follow the actual progress value. Queue counts remain authoritative even when safe enemies overlap near a full entrance.

The generic engine receives its configuration from the native host. Geometry, work, building slots, road limits, refusal policy, holds, successors, wave count, demand ramp and deadlines are scenario-owned. The current class pattern is fixed at two findings per three identities, and there is one configured incoming straight road per stage. Fan-in requiring different physical entry roads would need a geometry extension; this is not arbitrary future-architecture compatibility.

## Road/building mathematical evidence

[RoadStudy.py](RoadStudy.py) executed 1,792 declared analytical comparisons over paired immutable demand. [The retained results](road-mechanics-results.json) include accounting, per-stage occupancy, range and idle checks. The analytical three-stage aggregate-service model differs from the native four-stage parallel-per-packet model and is not a parity test. Its numeric winning policies cannot be copied directly into the playable game.

Candidate disposition: **BORROW** finite safe-road slack, scarce construction budget, physical range and distributed processing coverage. **REJECT** indefinite buffering as a win condition and upstream-only speed as a generally sufficient policy. Longer roads reduce dangerous exposure at a possible cost in completion; wide/shared placement and rapid/local processing trade coverage against pressure under some analytical contexts. A proposed buffer archetype remains unimplemented and is not claimed as a tested playable mechanic.

For the native default, 156 finding-bearing packets each hold output for eighty ticks. At one health unit per 120 inside-packet ticks, finishing all of them imposes at least 104 health units from that holding phase alone. More tower work cannot remove that holding cost. The starting 220 health therefore leaves a bounded margin for service, blocking and refusal. This is a fixture-specific lower bound, not a balance proof.

The directed native checks establish safe road travel through tick 27 on a 112-pixel road at four pixels/tick, danger starting on arrival at tick 28, and recurring pressure proportional to the number of arrived packets. With a test threshold of ten job-ticks, one arrived packet held for thirty ticks costs three health; two cost six. Held output remains dangerous. Transfer checks distinguish clear terminal completion from a finding continuing into advice, preserving the packet identity.

A real geometric decision is visible at the right-hand bridge: a level-one Rapid has range 106 and cannot reach the advice building roughly 109 pixels away; upgrading extends its range enough. A Relay reaches it immediately but adds less work per shot. Construction and upgrades use actual click/key actions in the campaign comparisons rather than injected free structures.

The simultaneous-arrival reservation defect is fixed and tracked as [#164](https://github.com/dearlordylord/hapsland/issues/164). An existing resident plus two arriving packets must share a two-slot building's remaining capacity: one newcomer enters, while the other waits safely on an ordinary road or is refused by the immediate policy. The native regression passes on the fixed core and fails on a scratch mutant restoring the old maximum-based count. This is a prototype-core report, not a production-reducer bug claim.

The initial native matrix ran 108 campaigns: four displayed contexts, nine actual construction/investment policies and admission intervals of twelve, eighteen and twenty-eight ticks. Thirty-five survived. Rapid-heavy reinforced defenses led the tested service/safety rankings across all four contexts, exposing a weak Batch niche rather than establishing broad balance.

One explicitly post-execution calibration was evaluated in scratch copies: Batch base work increased from nine to fourteen, and base range from 88 to 110, keeping cost 55 and reload eighteen ticks. The Batch policy's starting placement moved to the same two-site bridge used by its comparison policy, with its upgrade targets changed to those actual structures. This is a tested parameter-and-placement package, not an isolated causal estimate of either numeric change. It produced forty surviving campaigns in the same 108-case matrix and was adopted for the runnable prototype.

| Final native comparison at interval 18 ticks | Rapid bridge plus reinforcement | Batch bridge plus same reinforcement |
| --- | --- | --- |
| Default | 234 done, 0 refused, 78 health, 5,923 ticks | 234 done, 0 refused, 73 health, 5,959 ticks |
| Capture pressure | 234 done, 60 health, 5,980 ticks | 234 done, 58 health, 6,006 ticks |
| Review pressure | 213 done, 21 refused, 7 health, 6,063 ticks | 223 done, 11 refused, 24 health, 6,084 ticks |

Both reinforced policies buy and upgrade through the real game's input functions. They begin with different right-hand bridge processors, then follow the same affordable Rapid reinforcement pattern. Batch pays twenty more initial gold; remaining capital is included in the raw output. This creates a measured reason to prefer Batch under dense review pressure while Rapid retains its default/capture advantage. The matrix is not exhaustive and does not establish optimal play or equal usefulness of every tower.

The competent default witness finishes all 234 identities with no losses across six waves. The undefended default loses. Faster admission tends to expose refusals; slower admission can improve health and coverage at the cost of longer runs and eventual deadline risk. [The native headless output](validation-road.txt) retains directed fixtures, the baseline, the declared calibration and the final source replay. Every campaign tick audits packet conservation, building slots, road limits, pressure residual and health bounds.

Human engagement and teaching remain unmeasured. A suitable first playtest asks the player to predict whether a road, service building or retained-output capacity is causing pressure before choosing a placement. Compare that causal prediction with the outcome, then record voluntary retries and frustration separately from completion rate. Native macOS execution is also unverified; native Linux window/input observations are retained separately.

## Queue-board exploration

The native flow game represents work as persistent identified tokens that pass through configurable stations. Stations process work rather than destroy enemies. Healthy busy queues are allowed; old work, capacity refusals and unmet wave demand cost health. Work cannot disappear without a recorded completion or drop.

Run `./run-flow.sh` for the flow game; `./run.sh` still runs the original combat experiment. Both compile native executables locally. All authored input, timing, simulation and rendering for either game are Bend. `MechanicsStudy.py` is an offline analytical study, not a dependency of either launcher.

The backbone has three boundaries:

- `FlowModel.bend` defines generic station configuration, runtime stations, identified packets and game state.
- `FlowGame.bend` advances that state and applies player actions. It does not import Hapsland's canonical reducer or know product stage names.
- `FlowScenario.bend` supplies the teaching scenario: station labels, clear/finding routes, queue and resource limits, service and retention durations, wave demands and difficulty. The native host selects that scenario.

A station declares its normal and finding successors. Terminal routes finish work. Ordinary full destinations apply backpressure: the completed packet stays upstream until the transfer can happen. An immediate-refusal destination drops refused work and records the loss. Service completion and retained resource holding are separate phases. Tokens enter a downstream station after processing the tick's snapshot, so one token cannot traverse multiple stations in one tick.

The Hapsland scenario is a teaching approximation, not a replay of the production reducer. It illustrates source preparation, review capacity, pending advice and host output. Clear review outcomes bypass advice/output. Output completion means completion of the simulated host boundary, not proof that an agent received, read or repaired anything. Assignable workers and purchasable upgrades are game controls; their presence does not assert that the real Jev service is configurable in those ways.

The initial engine supports finite configured stage graphs, per-token clear/finding routes and station resource holding. The current demand generator remains a fixed game rule: six-wave-shaped counts of 18, 24, 30, 36, 42 and 48, and two findings per three offered demand identities; configuration can change the number of waves and deadlines but cannot yet author a different demand schedule. The native renderer exposes up to four station cards; the engine also runs a two-station example without a logic change. It does not yet represent one edit spawning several review units, cancellation generations, delivery uncertainty/reoffers or every retained-advice lifetime. Architecture changes expressible as stage, route, duration, capacity or refusal changes belong in scenario data. New semantics such as fan-out need an explicit engine extension and corresponding executable examples; configuration alone cannot promise compatibility with arbitrary future changes.

The prototype remains isolated in `prototype/bend-tower-defense`. It changes no product dispatch or delivery contract.

## Mathematical selection method

The study evaluates decisions rather than trying to assign a number to enjoyment. Its declared criteria are coverage of fixed demand, completed output, lost work, latency, resource occupancy and sensitivity to the scenario. A promising decision changes the best response in at least two contexts, has an observable consequence, and offers a tradeoff rather than a free improvement. Difficulty is assessed by the gap between simple policies and informed ones. These are proposed design criteria, not validated measures of human engagement or learning.

The conservation identity for the executable engine is:

```text
offered = live tokens + finished + dropped
```

Unserved wave demand is counted as offered and dropped at the wave deadline. This prevents slow admission from appearing successful by shrinking the denominator. For each station, the corresponding recurrence is occupancy next = occupancy now + accepted arrivals - successful departures - removals. Blocked transfers remain upstream. Refused transfers leave the live set and enter the drop counter.

A useful capacity estimate separates work from holding. With c workers, service duration s, R resource slots and additional holding duration h, the sustained throughput upper bound is approximately `min(c/s, R/(s+h))` when each item holds one slot during both phases. Routing matters: if only fraction p of arrivals visits a station, that station sees approximately p times the external arrival rate. These are planning bounds, not a guarantee against burst refusals or deadlines. The executable study uses its declared discrete model rather than assuming these bounds are exact.

Three decisions follow from these constraints:

- **Pacing:** releasing work faster improves coverage of a finite wave until downstream capacity starts refusing it. Slowing too far misses the wave's remaining demand.
- **Allocation:** moving a scarce worker changes one station's capacity at another station's expense. Queue length alone can be misleading when upstream work is about to arrive or resource holding dominates the destination.
- **Upgrades:** reducing service duration helps a service bottleneck. It cannot erase a capacity or retention constraint, and can increase pressure downstream.

The independent Python comparison explores a simplified loss network. Native Bend headless experiments exercise the actual playable engine. Their results must be read separately: agreement on a tradeoff supports the design hypothesis; it does not establish equivalence between two differently scoped models. Neither automated policies nor formal invariants establish that a person understood or enjoyed the mechanic.

## Play the flow game

After extracting this directory, run:

```sh
./run-road.sh
```

- **1–4** or click a card selects a station.
- **+ / =** assigns one reserve worker; **-** returns one worker when its reservations permit removal. There are six workers across four stations, initially one per station and two in reserve.
- **U** buys a service-speed upgrade for the selected station. The displayed price grows with its level; resource limits and holding duration remain independent.
- **[** admits faster; **]** admits slower. The HUD displays the actual interval in milliseconds. Demand identities and outcomes stay fixed.
- **N / Enter** starts a wave; **Space / P** pauses; **R** restarts the current scenario; **Escape** exits.
- **Tab** cycles the default, capture, review and advice bottleneck scenarios and resets the run. The selected scenario name appears in the HUD.

Each token retains its demand ID while moving between cards. Blue/gold distinguishes clear work from finding-bearing work; orange/red warns about age. Busy, waiting and held counts expose different occupancy. A refusal, age expiration or missed wave demand costs health. Each packet has a six-second age budget in the current scenario; each wave has an eighteen-second admission window. Configuration supplies these game durations, not production timing claims.

The four playable contexts use the same engine and renderer. The three bottleneck variants multiply the selected station's service duration by four and its holding duration by two. Route names and successor labels come from the configured graph. This demonstrates scenario changes without corresponding game-engine changes.

## Observed comparisons and current verdict

The analytical study retained **25,056** runs: 8,064 named-policy comparisons, 15,840 exploratory static-allocation grid runs and 1,152 exploratory fixed-demand pacing comparisons. Thirteen named policy pairs change advantage across contexts, and there is no named policy on every context's coverage/delivery Pareto frontier. See [the executable study](MechanicsStudy.py) and [its raw results and declarations](mechanics-results.json). The pacing extension is explicitly marked as an addition after the first run. The grid uses sixteen seeds, versus sixty-four for named policies; its best means are not the same estimate or evidence of a clear rate.

Candidate disposition: **BORROW** scarce worker/resource allocation and paced admission with fixed demand; **REJECT** naive occupancy gating as a generally beneficial policy in the studied loss network. Neither tested gate improves mean coverage across its eighteen contexts, although small delivery exceptions prevent claiming universal Pareto domination. The transient model uses explicit recurrence assertions; [MIT's queueing-model guidance](https://web.mit.edu/urban_or_book/www/book/chapter4/4.1.html) supports making its assumptions explicit, not treating a simplified model as the product.

The actual Bend engine ran **44 campaigns**, plus focused regression, pause, batching, transfer, retention and alternate-configuration checks. Full accounting/resource/worker invariants are checked for every tick of each first wave and at campaign completion. The retained [native headless evidence](validation-flow.txt) includes the final replay and source fingerprints.

| Actual-engine case | Policy | Observed outcome |
| --- | --- | --- |
| Default | Workers 1/2/2/1, interval 16 ticks, no upgrades | All 198 completed; 24 health; 3,786 ticks |
| Default | Same workers plus repeated affordable upgrades | All 198 completed; 24 health; 3,598 ticks; 720 more gold spent |
| Review bottleneck | Balanced workers with upgrades | Loses in wave 3; 42 completed |
| Review bottleneck | Review-focused workers 1/3/1/1 with same upgrade policy | All 198 completed; 24 health |
| Advice bottleneck | Balanced workers with upgrades | All 198 completed; 24 health |
| Advice bottleneck | Review-focused workers with same upgrade policy | 190 completed; 16 health |

Both investment policies attempt affordable upgrades every thirty ticks in the same review/advice/capture/output order; only the worker vector differs. The policy additions were exploratory and are recorded as amendments in the executable output. These examples show a causal allocation tradeoff; they do not establish an optimal strategy.

The default is an onboarding scenario. Upgrades are optional there and buy only a modest time improvement in the tested policy; they are not yet a strong independent decision. The original extreme-context static/greedy matrix loses every campaign. The investment witnesses establish reachable wins in each displayed bottleneck scenario, but broad player difficulty calibration remains open. The justified backbone is pacing plus scarce allocation, with speed upgrades retained for further exploration.

For a first human teaching check, play the default and review-bottleneck contexts in alternating order. Before acting, predict which station will refuse or hold work and whether moving a worker or buying speed will help. Afterward explain the observed result without looking at the source. Record correct causal predictions, repeated misconceptions, voluntary retries and frustration separately. In the advice context, compare the same two worker vectors instead of changing every variable at once. This protocol is proposed; no participant results exist. Enjoyment, challenge and learning should remain separate outcomes rather than a single weighted score.

The final [native window evidence](validation-flow-native.txt) exercises all four Tab-selected scenarios, worker assignment, wave start, pause, upgrade, reset and quit through the real launcher. [The paused view](preview-flow-paused.png) shows identified work across review, advice and resource-held output. Two paused observations held at tick 95; upgrading the selected review station changed budget from 82 to 32 without advancing the paused clock. Linux native execution is observed; macOS execution and human teaching/engagement are not.

Three prototype-core defects were fixed locally and recorded in the task tracker: [immutable demand outcomes #161](https://github.com/dearlordylord/hapsland/issues/161), [blocked-transfer reservations #162](https://github.com/dearlordylord/hapsland/issues/162), and [elapsed-zero worker reservations #163](https://github.com/dearlordylord/hapsland/issues/163). Each has a discriminating native regression: a scratch mutant restoring the defect exits 1 while the corrected core exits 0. These reports do not assert production-reducer defects. The prototype source is in the isolated worktree and downloadable bundle, with formal laws still proposed rather than approved/proved.

## Native prerequisites on macOS

Install [Bend](https://bend-lang.com/) and Apple's command-line developer tools if they are not already installed. The compiler's [native graphics guide](https://github.com/bendlang/bend/blob/main/guide/GUIDE.md) owns platform prerequisites. Development here uses Bend 2.0.34. On your Mac, a normal desktop session and the system Metal device supply the native window backend; this code uses CPU rendering and has no game GPU kernel.

```sh
xcode-select --install
brew install bendlang/bend/bend
cd /path/to/bend-tower-defense
./run-road.sh
```

The Homebrew command is listed in [Bend's release installation instructions](https://github.com/bendlang/bend/releases). Use the website installer if you do not use Homebrew; no installation is performed by this prototype.

The launcher compiles all Bend source for your own computer and starts the native window. No Node, browser, npm packages, credentials, Hapsland installation or Jev connection is needed. The first compile can take longer than launching the already built binary. The build goes under `$TMPDIR/hapsland-bend-road-defense-<uid>` (or `/tmp`); source remains in the worktree. Re-run the launcher after source changes. A Linux ARM64 binary is not a macOS executable.

On Linux, use an X11 or XWayland desktop with X11 development headers and Clang. This game was exercised here under Xvfb. The macOS launch itself is not validated by that Linux run.

The current road game has an [active gameplay preview](preview-road-play.png), [native window observations](validation-road-native.txt), and [directed checks and 108 campaign results](validation-road.txt). These observations exercise the final source on Linux ARM64; macOS execution and human teaching outcomes remain unvalidated.

## Play the original combat experiment

Place defenses while a wave runs or during preparation. The path must remain clear. Start with 120 gold and 15 lives; survive six waves. Runners move faster, armored enemies take more damage, and later waves bring more enemies. Kills fund more construction and upgrades. Preparing the next wave gives time to spend earned gold.

- **1** selects a gun (30 gold): rapid single-target damage.
- **2** selects frost (40 gold): slows enemies, with lower damage.
- **3** selects splash (55 gold): slower fire, area damage.
- **Left click** a valid spot to build, or an existing tower to select it.
- **U** upgrades the selected tower, up to level three; inspect the visible cost.
- **N / Enter** starts the next wave when the board is ready.
- **Space / P** pauses or resumes; **R** restarts; **Escape** exits.

Tower targeting, enemy movement, damage, slow duration, bounties, placement, costs, waves and terminal states are implemented in [Game.bend](Game.bend). [Model.bend](Model.bend) owns the state and path. [Render.bend](Render.bend) and [Font.bend](Font.bend) author the complete quadtree image and text. [Main.bend](Main.bend) owns input and the real-time clock using Bend's Base effects. Only the launcher is a shell script; no gameplay or rendering is implemented in a second language.

The game is independent of the Hapsland reducer and the earlier mechanics lab. No mechanic here changes product review behavior. These towers and enemies are ordinary game entities.

## Original combat timing and validation

Physics advances in fixed 20 ms ticks. The native driver accumulates elapsed monotonic milliseconds and retains partial ticks. It processes at most eight catch-up ticks after a stalled frame; a longer stall slows game time rather than applying an unbounded jump. Pause and preparation clear the accumulator. Rendering rate therefore does not select damage or movement per frame, although sustained rendering stalls can slow the game.

For type/termination checks with a five-second bound, run `./bend-check Main.bend --check-only` and `./bend-check Headless.bend --check-only`. The wrapper needs `timeout`, or `gtimeout` from coreutils on macOS. Native compilation is separate from this checking limit:

```sh
bend Headless.bend -o /tmp/bend-tower-defense-headless
/tmp/bend-tower-defense-headless --threads 4
```

Headless scenarios use the same pure gameplay code and run entirely in Bend. They inspect pause, preparation, economy, road placement, exact tick batching, restart, tower kills and bounded defended/undefended campaigns. They are finite examples, not human engagement evidence or a proof over all game states.

The retained [headless output](validation-headless.txt) records fifteen passing checks on Linux ARM64 with Bend 2.0.34, compiling `Headless.bend` to a native binary and running with four CPU threads. `Main.bend --verdict` and `Headless.bend --verdict` also pass the compiler's second kernel check under the five-second bound; these checks validate the program definitions, while the proposed behavioral laws below remain open. Directed scenarios distinguish gun bounty accounting, splash damage, frost slowing and upgrade affordability. An undefended campaign loses in wave two; three unchanged guns lose in wave six; spending between waves wins all six with fifteen lives. The draft HP ramp was raised from nine to eighteen points per wave after the original three-gun setup cleared the entire game without further spending. This tuning creates a tested need to invest for that setup, not a claim that every weapon or strategy is balanced.

Native input/render observations are retained in [validation-native.txt](validation-native.txt), with [a combat preview](preview-combat.png) and [paused preview](preview-paused.png). Real window injection exercised build, select, upgrade, wave start, pause and quit under X11; the tick advanced 150 steps in approximately three seconds of normal play and held at 461 during the observed paused interval. Those are local observations, not a frame-rate or macOS benchmark.

[LAWS.bend](LAWS.bend) holds proposed behavioral laws, including the flow accounting, identity, capacity and workload-independence requirements, for a later formal pass. Human approval precedes their proof under [the Bend law-driven development skill](/home/node/.codex/skills/bend-ldd/SKILL.md), which states: “no proof is written against it until the human approves it.” [PROOF.bend](PROOF.bend) therefore contains no proofs and intentionally reports open laws. Typechecking gameplay is not a claim that those behavioral laws are proved. This does not prevent running the game. The current source bundle and worktree contain the runnable work; no new source commit is claimed while the skill’s formal-law gate is open.
