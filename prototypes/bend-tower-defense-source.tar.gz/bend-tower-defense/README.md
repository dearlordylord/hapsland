# Bend tower defense

**Purpose:** Run a standalone real-time tower-defense game authored entirely in Bend.
**Status:** Throwaway gameplay prototype; see validation evidence for executed checks.
**Authority:** Implementation and validation evidence, not an accepted Hapsland product contract.
**Expected use:** Play locally on macOS or Linux, inspect the Bend mechanics, and decide whether this direction merits another iteration.
**Lifecycle:** At the tower-defense direction decision milestone, consolidate useful mechanics and evidence into its owning game specification or issue, update inbound links, and delete rejected prototype code and temporary evidence. Preserve provenance in the isolated prototype worktree/branch or source bundle. Revisit these instructions when native controls or the tested Bend version change.

## Run on macOS

Install [Bend](https://bend-lang.com/) and Apple's command-line developer tools if they are not already installed. The compiler's [native graphics guide](https://github.com/bendlang/bend/blob/main/guide/GUIDE.md) owns platform prerequisites. Development here uses Bend 2.0.34. On your Mac, a normal desktop session and the system Metal device supply the native window backend; this code uses CPU rendering and has no game GPU kernel.

```sh
xcode-select --install
brew install bendlang/bend/bend
cd /path/to/bend-tower-defense
./run.sh
```

The Homebrew command is listed in [Bend's release installation instructions](https://github.com/bendlang/bend/releases). Use the website installer if you do not use Homebrew; no installation is performed by this prototype.

The launcher compiles all Bend source for your own computer and starts the native window. No Node, browser, npm packages, credentials, Hapsland installation or Jev connection is needed. The first compile can take longer than launching the already built binary. The build goes under `$TMPDIR/hapsland-bend-tower-defense-<uid>` (or `/tmp`); source remains in the worktree. Re-run the launcher after source changes. A Linux ARM64 binary is not a macOS executable.

On Linux, use an X11 or XWayland desktop with X11 development headers and Clang. This game was exercised here under Xvfb. The macOS launch itself is not validated by that Linux run.

## Play

Place defenses while a wave runs or during preparation. The path must remain clear. Start with 120 gold and 15 lives; survive six waves. Runners move faster, armored enemies take more damage, and later waves bring more enemies. Kills fund more construction and upgrades. Preparing the next wave gives time to spend earned gold.

- **1** selects a gun (30 gold): rapid single-target damage.
- **2** selects frost (40 gold): slows enemies, with lower damage.
- **3** selects splash (55 gold): slower fire, area damage.
- **Left click** a valid spot to build, or an existing tower to select it.
- **U** upgrades the selected tower, up to level three; inspect the visible cost.
- **N / Enter** starts the next wave when the board is ready.
- **Space / P** pauses or resumes; **R** restarts; **Escape** exits.

Tower targeting, enemy movement, damage, slow duration, bounties, placement, costs, waves and terminal states are implemented in [Game.bend](Game.bend). [Model.bend](Model.bend) owns the state and path. [Render.bend](Render.bend) and [Font.bend](Font.bend) author the complete quadtree image and text. [Main.bend](Main.bend) owns input and the real-time clock using Bend's Base effects. Only the launcher is a shell script; no gameplay or rendering is implemented in a second language.

The game is independent of the Hapsland reducer and the earlier mechanics lab. No mechanic here changes product review behavior. These towers and enemies are ordinary game entities.

## Timing and validation

Physics advances in fixed 20 ms ticks. The native driver accumulates elapsed monotonic milliseconds and retains partial ticks. It processes at most eight catch-up ticks after a stalled frame; a longer stall slows game time rather than applying an unbounded jump. Pause and preparation clear the accumulator. Rendering rate therefore does not select damage or movement per frame, although sustained rendering stalls can slow the game.

For type/termination checks with a five-second bound, run `./bend-check Main.bend --check-only` and `./bend-check Headless.bend --check-only`. The wrapper needs `timeout`, or `gtimeout` from coreutils on macOS. Native compilation is separate from this checking limit:

```sh
bend Headless.bend -o /tmp/bend-tower-defense-headless
/tmp/bend-tower-defense-headless --threads 4
```

Headless scenarios use the same pure gameplay code and run entirely in Bend. They inspect pause, preparation, economy, road placement, exact tick batching, restart, tower kills and bounded defended/undefended campaigns. They are finite examples, not human engagement evidence or a proof over all game states.

The retained [headless output](validation-headless.txt) records fifteen passing checks on Linux ARM64 with Bend 2.0.34, compiling `Headless.bend` to a native binary and running with four CPU threads. `Main.bend --verdict` and `Headless.bend --verdict` also pass the compiler's second kernel check under the five-second bound; these checks validate the program definitions, while the proposed behavioral laws below remain open. Directed scenarios distinguish gun bounty accounting, splash damage, frost slowing and upgrade affordability. An undefended campaign loses in wave two; three unchanged guns lose in wave six; spending between waves wins all six with fifteen lives. The draft HP ramp was raised from nine to eighteen points per wave after the original three-gun setup cleared the entire game without further spending. This tuning creates a tested need to invest for that setup, not a claim that every weapon or strategy is balanced.

Native input/render observations are retained in [validation-native.txt](validation-native.txt), with [a combat preview](preview-combat.png) and [paused preview](preview-paused.png). Real window injection exercised build, select, upgrade, wave start, pause and quit under X11; the tick advanced 150 steps in approximately three seconds of normal play and held at 461 during the observed paused interval. Those are local observations, not a frame-rate or macOS benchmark.

[LAWS.bend](LAWS.bend) holds proposed behavioral laws for a later formal pass. Human approval precedes their proof under [the Bend law-driven development skill](/home/node/.codex/skills/bend-ldd/SKILL.md), which states: “no proof is written against it until the human approves it.” [PROOF.bend](PROOF.bend) therefore contains no proofs and intentionally reports open laws. Typechecking gameplay is not a claim that those behavioral laws are proved. This does not prevent running the game.
